//
//  This class was created by Nonnus,
//  who graciously decided to share it with the CocoaHTTPServer community.
//

#import <Foundation/Foundation.h>


@interface localhostAddresses : NSObject {

}

+ (void)list;

@end
