#import <Cocoa/Cocoa.h>
//#import <UIKit/UIKit.h>
@class   HTTPServer;

@interface AppDelegate : NSObject
{
	HTTPServer *httpServer;
}
@end
